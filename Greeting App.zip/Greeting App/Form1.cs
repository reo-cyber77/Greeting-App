namespace Greeting_App
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string name = Input_Name.Text.Trim();
            string color = Color_Input.Text.Trim();

            Greeting_Label.Text = string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(color)
                ? "Please enter both your name and favorite color."
                : $"Hello, {name}! Your favorite color is {color}.";
            Greeting_Label.Visible = true;
        }

        private void Clear_Btn_Click(object sender, EventArgs e)
        {
            Input_Name.Text = "";
            Color_Input.Text = "";
            Greeting_Label.Visible = false;
        }
    }
}
