﻿namespace Greeting_App
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            app_title = new Label();
            Name_Label = new Label();
            Fav_Color_Label = new Label();
            Input_Name = new TextBox();
            Color_Input = new TextBox();
            Greeting_btn = new Button();
            Clear_Btn = new Button();
            Greeting_Label = new Label();
            SuspendLayout();
            // 
            // app_title
            // 
            app_title.AutoSize = true;
            app_title.Location = new Point(331, 17);
            app_title.Name = "app_title";
            app_title.Size = new Size(97, 15);
            app_title.TabIndex = 0;
            app_title.Text = "My Greeting App";
            app_title.Click += label1_Click;
            // 
            // Name_Label
            // 
            Name_Label.AutoSize = true;
            Name_Label.Location = new Point(180, 45);
            Name_Label.Name = "Name_Label";
            Name_Label.Size = new Size(72, 15);
            Name_Label.TabIndex = 1;
            Name_Label.Text = "Your Name: ";
            Name_Label.Click += label1_Click_1;
            // 
            // Fav_Color_Label
            // 
            Fav_Color_Label.AutoSize = true;
            Fav_Color_Label.Location = new Point(180, 74);
            Fav_Color_Label.Name = "Fav_Color_Label";
            Fav_Color_Label.Size = new Size(87, 15);
            Fav_Color_Label.TabIndex = 2;
            Fav_Color_Label.Text = "Favorite Color: ";
            // 
            // Input_Name
            // 
            Input_Name.Location = new Point(268, 42);
            Input_Name.Name = "Input_Name";
            Input_Name.Size = new Size(100, 23);
            Input_Name.TabIndex = 3;
            // 
            // Color_Input
            // 
            Color_Input.Location = new Point(268, 74);
            Color_Input.Name = "Color_Input";
            Color_Input.Size = new Size(100, 23);
            Color_Input.TabIndex = 4;
            // 
            // Greeting_btn
            // 
            Greeting_btn.Location = new Point(180, 113);
            Greeting_btn.Name = "Greeting_btn";
            Greeting_btn.Size = new Size(113, 24);
            Greeting_btn.TabIndex = 5;
            Greeting_btn.Text = "Create Greeting";
            Greeting_btn.UseVisualStyleBackColor = true;
            Greeting_btn.Click += button1_Click;
            // 
            // Clear_Btn
            // 
            Clear_Btn.Location = new Point(308, 114);
            Clear_Btn.Name = "Clear_Btn";
            Clear_Btn.Size = new Size(75, 23);
            Clear_Btn.TabIndex = 6;
            Clear_Btn.Text = "Clear";
            Clear_Btn.UseVisualStyleBackColor = true;
            Clear_Btn.Click += Clear_Btn_Click;
            // 
            // Greeting_Label
            // 
            Greeting_Label.AutoSize = true;
            Greeting_Label.Location = new Point(283, 158);
            Greeting_Label.Name = "Greeting_Label";
            Greeting_Label.Size = new Size(38, 15);
            Greeting_Label.TabIndex = 7;
            Greeting_Label.Text = "label1";
            Greeting_Label.Visible = false;
            Greeting_Label.Click += label1_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(Greeting_Label);
            Controls.Add(Clear_Btn);
            Controls.Add(Greeting_btn);
            Controls.Add(Color_Input);
            Controls.Add(Input_Name);
            Controls.Add(Fav_Color_Label);
            Controls.Add(Name_Label);
            Controls.Add(app_title);
            Name = "Form1";
            Text = "Simple Greeting App";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label app_title;
        private Label Name_Label;
        private Label Fav_Color_Label;
        private TextBox Input_Name;
        private TextBox Color_Input;
        private Button Greeting_btn;
        private Button Clear_Btn;
        private Label Greeting_Label;
    }
}
